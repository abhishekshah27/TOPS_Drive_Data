import java.io.IOException;
import java.io.PrintWriter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MyFilter implements Filter{

	public void init(FilterConfig arg0) throws ServletException {
		System.out.println("Init Filter2");
	}
	
	public void doFilter(ServletRequest req, ServletResponse resp,
			FilterChain chain) throws IOException, ServletException {
			
		
		resp.setContentType("text/html");
		PrintWriter out=resp.getWriter();
		
		String name=req.getParameter("name");
		String password=req.getParameter("password");
		
		//String regex = "^[a-zA-Z0-9]+$";

		//Pattern pattern = Pattern.compile(regex);

		//Matcher matcher = pattern.matcher(name);
	  	//System.out.println(matcher.matches());
	  	//if(matcher.matches()==false)
	  	//{
	  	//	out.print("Please Enter Proper Name");
		//	req.getRequestDispatcher("index.jsp").include(req, resp);
	  	//}
		
		if(password.equalsIgnoreCase(""))
		{
			out.print("Please Enter Password");
			req.getRequestDispatcher("index.jsp").include(req, resp);
		}
		else if(password.equals("admin")){
		chain.doFilter(req, resp);//sends request to next resource
		}
		else{
		out.print("username or password error!");
		req.getRequestDispatcher("index.jsp").include(req, resp);
		}
		
	}
	public void destroy() {
		System.out.println("Destroy Filter2");
	}

	

}
