package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.StudentDao;
import com.sun.xml.internal.ws.client.Stub;
import com.tops.Student;
@WebServlet("/ActionController")
public class ActionController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Action Controller");
		String action=request.getParameter("action");
		System.out.println(action);
		if(action.equalsIgnoreCase("insert"))
		{
			Student s=new Student();
			String h[]=request.getParameterValues("h");
			String hobbies="";
			for(int i=0;i<h.length;i++)
			{
				hobbies+=h[i]+",";
			}
			s.setHobby(hobbies);
			StudentDao sdao=new StudentDao();
			sdao.insertHobby(s);
		}
		
	}

}
