package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import com.tops.Student;

public class StudentDao {

	public void insertHobby(Student s)
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3307/test","root","");
			String sql="insert into student1 (hobby) values(?)";
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1, s.getHobby());
			pst.executeUpdate();
			System.out.println("Data Inserted Successfully");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
