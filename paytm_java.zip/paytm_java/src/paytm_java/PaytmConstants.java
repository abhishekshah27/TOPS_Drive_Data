package paytm_java;
public class PaytmConstants {
  public final static String MID="NmDWNM56157312598290";
  public final static String MERCHANT_KEY="ungwuXLN#dzoL_z4";
  public final static String INDUSTRY_TYPE_ID="Retail";
  public final static String CHANNEL_ID="WEB";
  public final static String WEBSITE="worldpressplg";
  public final static String PAYTM_URL="https://securegw-stage.paytm.in/theia/processTransaction"; 
  
}

