package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.bean.ForgotPswd;
import com.util.ConnectionUtil;

public class ForgotDao {
	
	public ForgotPswd checkEmail(String email)
	{
		ForgotPswd f=new ForgotPswd();
		try {
		
			Connection conn=ConnectionUtil.createConnection();
			String sql="select * from  emailDemo where email=?";
			PreparedStatement stmt=conn.prepareStatement(sql);
			stmt.setString(1, email);
			ResultSet rs=stmt.executeQuery();
			if(rs.next())
			{
				f.setId(rs.getInt("id"));
				f.setEmail(rs.getString("email"));
				f.setName(rs.getString("name"));
			}
			else

			{
				f=null;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return f;
		
	}
	public int resetPassword(ForgotPswd f)
	{
		int r=0;
		try {
			Connection conn=ConnectionUtil.createConnection();
			String sql="update  emailDemo set password=? where id=?";
			PreparedStatement stmt=conn.prepareStatement(sql);
			stmt.setString(1, f.getPassword());
			stmt.setInt(2, f.getId());
			r=stmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return r;
	}

}