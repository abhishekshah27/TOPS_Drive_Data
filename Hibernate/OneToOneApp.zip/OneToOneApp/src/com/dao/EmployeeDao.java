package com.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.bean.Employee;
import com.bean.EmployeePI;
import com.util.EmployeeUtil;

public class EmployeeDao {

	public static void insertEmployyePI(EmployeePI epi)
	{
		Session session=EmployeeUtil.createSession();
		Transaction tr=session.beginTransaction();
		session.save(epi);
		tr.commit();
		session.close();
	}
	public static void insertEmployye(Employee epi)
	{
		Session session=EmployeeUtil.createSession();
		Transaction tr=session.beginTransaction();
		session.save(epi);
		tr.commit();
		session.close();
	}
	public static List<Employee> getAllEmployee()
	{
		Session session=EmployeeUtil.createSession();
		List<Employee> list=session.createQuery("from Employee").list();
		return list;
	}
}
