package com.spring;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ActionController {

	@RequestMapping(value="/",method=RequestMethod.GET)
	public String index(ModelMap model)
	{
		return "index";
	}
	@RequestMapping(value="/hello",method=RequestMethod.GET)
	public String hello(ModelMap model)
	{
		model.addAttribute("msg","This Is Hello File");
		System.out.println("Hello Called");
		return "hello";
	}
	@RequestMapping(value="/welcome",method=RequestMethod.GET)
	public String welcome(ModelMap model)
	{
		model.addAttribute("msg","This Is Welcome File");
		System.out.println("Welcome Called");
		return "welcome";
	}
	@RequestMapping(value="/passParam",method=RequestMethod.POST)
	public String formCall(HttpServletRequest request,HttpServletResponse response,ModelMap model)
	{
		String name=request.getParameter("name");
		String address=request.getParameter("address");
		model.addAttribute("name",name);
		model.addAttribute("address",address);
		return "show";
	}
	
	@RequestMapping(value="/formCall",method=RequestMethod.POST)
	public ModelAndView formCall1(HttpServletRequest request,HttpServletResponse response)
	{
		
		String name=request.getParameter("name");
		String address=request.getParameter("address");
		//ModelAndView model=new ModelAndView("show","n",name);
		
		ModelMap map=new ModelMap();
		map.addAttribute("name", name);
		map.addAttribute("address", address);
		ModelAndView model=new ModelAndView("show", "map",map);
		return model;
	}
}
