package com.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bo.PersonBo;
import com.spring.Person;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext a=new ClassPathXmlApplicationContext("Beans.xml");
		PersonBo pbo=(PersonBo) a.getBean("personBo");
		Person p=new Person();
		p.setPname("ABC");
		p.setPaddress("Ahmedabad");
		pbo.addPerson(p);
	}
}
