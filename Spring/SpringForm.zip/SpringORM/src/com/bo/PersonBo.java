package com.bo;

import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.dao.PersonDao;
import com.spring.Person;

public class PersonBo {

	private PersonDao personDao;
	
	public PersonDao getPersonDao() {
		return personDao;
	}
	public void setPersonDao(PersonDao personDao) {
		this.personDao = personDao;
	}
	public void addPerson(Person p)
	{
		this.personDao.addPerson(p);
	}
	public void updatePerson(Person p)
	{
		this.personDao.updatePerson(p);
	}
	public void deletePerson(int pid)
	{
		this.personDao.deletePerson(pid);
	}
	public Person getPersonById(int pid)
	{
		return this.personDao.getPersonById(pid);
	}
	public List<Person> getAllPerson()
	{
		return this.personDao.getAllPerson();		
	}
}
