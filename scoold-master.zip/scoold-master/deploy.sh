#!/bin/bash

OLDVER=$(grep -Po '<version>\K[^<]+' pom.xml | head -n1)
echo "Last version tag was ${OLDVER}"
read -e -p "New version tag: " ver

sed -i -e "0,/$OLDVER/s/$OLDVER/$ver/" pom.xml
sed -i -e "s/$OLDVER/$ver/g" docs/index.html
git add -A && git commit -m "Release v$ver."
git tag "$ver"
git push origin master
git push --tags
echo "v$ver" > changelog.txt && \
echo "" >> changelog.txt && \
git log $OLDVER..HEAD --oneline >> changelog.txt && \
echo "" >> changelog.txt && \
hub release create -F changelog.txt $ver && \
rm changelog.txt
echo "--done--"
