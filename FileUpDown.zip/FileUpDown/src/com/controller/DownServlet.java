package com.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.ImgClass;
import com.dao.DaoClass;

@WebServlet("/DownServlet")
public class DownServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int id=Integer.parseInt(request.getParameter("id"));
		DaoClass dao=new DaoClass();
		ImgClass image=dao.viewImageById(id);
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String filePath=request.getServletContext().getRealPath("");
		String filename=image.getImgname();
		response.setContentType("APPLICATION/OCTET-STREAM");	// This line describe the datatype, APPLICATION/OCTET-STREAM stands for binary data.
		response.setHeader("Content-Disposition", "attachment; filename=\""
				+ filename + "\""); 		// "attachment" which force to download the file, "inline" which displays the file without fourcing to download it.
		FileInputStream input=new FileInputStream(filePath+File.separator+image.getImgname());
		
		int i;
		while((i=input.read())!=-1)
		{
			out.write(i);
		}
		
		input.close();
		out.close();
		
	}
}
