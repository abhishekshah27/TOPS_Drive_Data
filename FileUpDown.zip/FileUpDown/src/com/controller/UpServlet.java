package com.controller;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.bean.ImgClass;
import com.dao.DaoClass;

@WebServlet("/UpServlet")
public class UpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		DiskFileItemFactory factory=new DiskFileItemFactory();
		ServletFileUpload sfu=new ServletFileUpload(factory);
		File file=null;
		String path=null, imagename=null;
		FileItem fItem=null;
		DaoClass dao=new DaoClass();
		int result=0;
		ImgClass img=new ImgClass();
		try {
			List<FileItem> list=sfu.parseRequest(request);
			for(FileItem item:list)
			{
				if(!item.isFormField())
				{
					fItem=item;
					path=request.getServletContext().getRealPath("");
					System.out.println("Path :- "+path);
					imagename=item.getName();
					System.out.println("Iamge Name :- "+imagename);
					img.setImgname(imagename);
				}
				
			}
			
			file=new File(path+File.separator+imagename);
			System.out.println("Path Specified in File Constructor :- "+path+File.separator+imagename);
			fItem.write(file);
			result=dao.saveImage(img);
			
			if(result>0)
			{
				response.sendRedirect("ViewImage.jsp");
			}
			else
			{
				response.sendRedirect("UploadImage.jsp");
			}
			
			
			
			
/*			if(result>0){
				System.out.println("File Successfully saved in Data Base:.....");
				//response.sendRedirect("ViewImage.jsp");
				
				response.setContentType("text/html");
				PrintWriter out=response.getWriter();
				out.println("<html><body>");
				out.println("<img src="+file.getAbsolutePath()+" alt='no image' />");
				out.println("</body></html>");
			}
			else
			{
				System.out.println("Error in saving the filr to DataBase...");
				response.sendRedirect("UploadImage.jsp");
				
				
				
				
			}*/
			
			System.out.println("File Writen (Absolute Path) :"+file.getAbsolutePath());
			
		} catch (FileUploadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
