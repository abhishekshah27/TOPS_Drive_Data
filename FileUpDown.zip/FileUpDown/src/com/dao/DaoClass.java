package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bean.ImgClass;
import com.util.DBConnection;

public class DaoClass {

	Connection con=null;
	PreparedStatement ps=null;
	ResultSet rs=null;
	int result;
	List<ImgClass> list=new ArrayList<ImgClass>();
	
	public int saveImage(ImgClass img)
	{
		final String insert="insert into image(ImageName) values (?)";
		
		con=DBConnection.getConnection();
		try {
			ps=con.prepareStatement(insert);
			ps.setString(1, img.getImgname());
			result=ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	
	
	public List<ImgClass> viewImage()
	{
		final String view="select * from image";
		
		con=DBConnection.getConnection();
		
		try {
			ps=con.prepareStatement(view);
			rs=ps.executeQuery();
			while(rs.next())
			{
				ImgClass img=new ImgClass();
				img.setId(rs.getInt("id"));
				img.setImgname(rs.getString("ImageName"));
				list.add(img);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}
	
	public ImgClass viewImageById(int id)
	{
		ImgClass image=null;
		final String query="select * from image where id=?";
		con=DBConnection.getConnection();
		try {
			ps=con.prepareStatement(query);
			ps.setInt(1, id);
			rs=ps.executeQuery();
			while(rs.next())
			{
				image=new ImgClass();
				image.setImgname(rs.getString("ImageName"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return image;
	}
}
