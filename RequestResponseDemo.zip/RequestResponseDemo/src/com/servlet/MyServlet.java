package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/MyServlet")
public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String action=request.getParameter("action");
		if(action.equalsIgnoreCase("login"))
		{
			String uname=request.getParameter("uname");
			String pass=request.getParameter("pass");
			
			System.out.println("UNAME : "+uname);
			System.out.println("Pass : "+pass);
			
			if(uname.equalsIgnoreCase("tops") && pass.equalsIgnoreCase("tops"))
			{
				request.setAttribute("uname", uname);
				request.getRequestDispatcher("home.jsp").forward(request, response);
			}
			else if(uname.equalsIgnoreCase("") || pass.equalsIgnoreCase(""))
			{
				out.println("Your User Name Or Password Is Missing");
				request.getRequestDispatcher("login.jsp").include(request, response);
			}
			else
			{
				out.println("Your User Name Or Password Is Incorrect");
				request.getRequestDispatcher("login.jsp").include(request, response);
			}
		}
	}

}
